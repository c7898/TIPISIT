package nomecognome;


import java.io.FileWriter;
import java.io.IOException;
import java.util.EmptyStackException;


public class ThreadScrittura extends Thread {
	Container C2;


	public ThreadScrittura(Container C2) {
		this.C2 = C2;
	}

	public void run() {
		
		FileWriter writer = null;
		try {
			writer = new FileWriter("./verifica.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			

		boolean lavoro=true;
		String line;
		while(lavoro) {
			
			try {
					line= C2.get();
	            	writer.write(line);
		           
	            	sleep(1);

			} catch (EmptyStackException e) {
				if(C2.isFinish()) {
					lavoro=false;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		 try {
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
