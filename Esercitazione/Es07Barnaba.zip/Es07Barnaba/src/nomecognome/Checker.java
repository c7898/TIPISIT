package nomecognome;

import java.util.EmptyStackException;

public class Checker extends Thread{
	Container C1;
	Container C2;
	ThWorkName Name;
	ThWorkSurname Surname;
	public Checker(Container C1, Container C2) {
		this.C1=C1;
		this.C2=C2;
		
		
	}
	
	public synchronized void run() {
		String line;
		String Nome;
		String Cognome;
		String line2;
		boolean lavoro=true;
		
		while(lavoro) {
			
			try {
				line= C1.get();
				String[] mioarray = line.split("/");
				Nome = mioarray[1];
				Cognome = mioarray[0];
				Name = new ThWorkName(Nome);
				Surname = new ThWorkSurname(Cognome);
				Name.start();
				Surname.start();
				Name.join();
				Surname.join();
				if (Name.var == 0 && Surname.var == 0) {
					line2= ("Cognome: " + Cognome.toUpperCase() + " Nome: " + Nome.substring(0, 1).toUpperCase()+ Nome.substring(1).toLowerCase() + "\n");
					C2.put(line2);
					
				}
				sleep(1);
			}catch (EmptyStackException e) {
				if(C1.isFinish()) {
					lavoro=false;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		C2.setFinish();
	}

}
