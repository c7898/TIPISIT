package nomecognome;

public class ThWorkSurname extends Thread {
	
	String ThWorkSurname;
	ThWorkName n;
	int var;
	
	/**
	 * Costruttore della classe
	 * @param Cognome stringa che rappresenta il nome testuale...
	 */
	public ThWorkSurname(String ThWorkSurname) {
		this.ThWorkSurname=ThWorkSurname;
		n=new ThWorkName(ThWorkSurname);
	}
	
	public void run() {

		n.verifica(ThWorkSurname,3);
		if(n.var==1) {
			var=1;
		}

	}

}
