package nomecognome;

public class ThWorkName extends Thread {
	String Nome;
	int c;
	int var;
	
	public ThWorkName(String Nome) {
		this.Nome=Nome;
	}
	
	public void run() {
		verifica(Nome,2);
	}
	public void verifica(String Nome, int c) {
		var=0;
		if (Nome.length()<c) {
			var=1;
		}
		
		for (int i = 0; i < Nome.length(); i++) {
			char ch = Nome.charAt(i);
			Character.isLetter(ch);
			if(Character.isLetter(ch)== false) {
				var=1;
			}
		}
	}
}
