package nomecognome;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try {
			File inputString = new File("strings.txt");
			Scanner input = new Scanner(inputString);
			Container C1 = new Container();
			Container C2 = new Container();
			Threadletture threadletture = new Threadletture(input, C1);
			ThreadScrittura threadscrittura = new ThreadScrittura(C2);
			Checker Check = new Checker(C1, C2);
			System.out.println("Wait...");
			threadletture.start();	
			Check.start();
			threadscrittura.start();
			threadletture.join();
			Check.join();
			threadscrittura.join();
			input.close();
			System.out.println("Fine esequzione");
		} 
		catch(FileNotFoundException e) {
			System.out.println("Attenzione, non sto riuscendo a trovare il file...");
		}
		catch (Exception e) {
			System.out.println("Eccezione non prevista...");
			e.printStackTrace();
		}

	}

}
