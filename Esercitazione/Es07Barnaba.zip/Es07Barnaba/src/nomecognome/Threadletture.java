package nomecognome;

import java.util.Scanner;

public class Threadletture extends Thread {
	Scanner input;
	Container C1;
	public Threadletture(Scanner input, Container C1) {
		this.input=input;
		this.C1=C1;
		
	}
	
	public void run() {
		String line;
		while (input.hasNextLine()) {
			line = input.nextLine();
			C1.put(line);
		}
		C1.setFinish();
	}
}
