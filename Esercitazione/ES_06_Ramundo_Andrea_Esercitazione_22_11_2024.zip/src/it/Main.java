package it;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) throws IOException {
		
		
        try {
            File inputString = new File("strings.txt");
            Scanner input = new Scanner(inputString);
            FileWriter writer = new FileWriter("strings1.txt");
          
            while (input.hasNextLine()) { 
                String line = input.nextLine();
            	Cognome surname=new Cognome(line);
            	Nome name=new Nome(line);
            	name.start();
            	surname.start();
            	
            	try {
					name.join();
					surname.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
            	
            	writer.write("Nome:"+name.stringa() + " Cognome: "+surname.stringa()+ "\n");
            		
            }
            input.close();
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File non trovato: " + e.getMessage());
        }
	}

}
