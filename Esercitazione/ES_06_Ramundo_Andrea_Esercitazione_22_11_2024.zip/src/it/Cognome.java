package it;

public class Cognome extends Thread {

	public String dati;
	private int c;
	public Cognome(String dati) {
		this.dati=dati;
	}
	boolean verifica;
	
    public void run() {
        c = 0; 

        if (dati == null || !dati.contains("/")) {
            System.out.println("Errore: formato non valido. Deve contenere il carattere '/'");
            c = 1; 
            return;
        }

        int separatorIndex = dati.indexOf('/');
        String str = dati.substring(separatorIndex+1);

        Lenght(str);
        Carattere(str);
    }
	
    public void Carattere(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isLetter(str.charAt(i))) {
                c = 1;
                System.out.println("Ci sono caratteri speciali");
                break; 
            }
        }
    }
    
    
    public void Lenght(String str) {
        if (str.length() <= 3) {
            System.out.println("Deve contenere almeno 2 caratteri");
            c = 1;
        }
    }
	
	

	public String stringa() {
        if (c == 0) {
            int separatorIndex = dati.indexOf('/');
            return dati.substring(separatorIndex+1);
        }
        return " non corretto";
    }
	
	
	
	
}
