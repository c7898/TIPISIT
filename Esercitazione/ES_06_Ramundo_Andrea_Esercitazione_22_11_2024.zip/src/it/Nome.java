package it;

public class Nome extends Thread implements Check {
    public String dati;
    private int c;

    public Nome(String dati) {
        this.dati = dati;
    }

    public void run() {
        c = 0; 

        if (dati == null || !dati.contains("/")) {
            System.out.println("Errore: formato non valido. Deve contenere il carattere '/'");
            c = 1; 
            return;
        }

        int separatorIndex = dati.indexOf('/');
        String str = dati.substring(0, separatorIndex);
        Lenght(str);
        Carattere(str);
    }

    public String stringa() {
        if (c == 0) {
            int separatorIndex = dati.indexOf('/');
            return dati.substring(0, 1).toUpperCase() + dati.substring(1, separatorIndex).toLowerCase();
        }
        return " non corretto";
    }

    public void Lenght(String str) {
        if (str.length() <= 2) {
            System.out.println("Deve contenere almeno 2 caratteri");
            c = 1;
        }
    }

    public void Carattere(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isLetter(str.charAt(i))) {
                c = 1;
                System.out.println("Ci sono caratteri speciali");
                break; 
            }
        }
    }
    
}
