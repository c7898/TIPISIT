package it;

public interface Check {
	
	public void Lenght(String str);
	public void Carattere(String str);
	
}
