package thread;

public class thread_2 extends Thread {

	protected String nome;
	
	public thread_2(String nome) {
		this.nome=nome;
	}
	
	public void run() {
		
		for(int i=1;i<=10;i++) {
		System.out.println(i+" Ciao sono "+nome);
		try {
			sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		}
		
	}
}