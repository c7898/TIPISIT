package thread;

public class thread_1 {

	public static void main(String[] args) {
		
		thread_2 t1=new thread_2("Andrea");
		t1.start();
		thread_2 t2=new thread_2("Antonio");
		t2.start();
	}

}
