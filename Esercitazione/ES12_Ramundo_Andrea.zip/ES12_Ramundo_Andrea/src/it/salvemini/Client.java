package it.salvemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) {
		String host = "localhost"; // Indirizzo del server
		int port = 1234; // Porta del server
		try (Socket socket = new Socket(host, port);
				BufferedReader sockIN = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				PrintWriter sockOUT = new PrintWriter(socket.getOutputStream(), true);
				Scanner tastiera = new Scanner(System.in);) {
			System.out.println(
					"Connesso al server " + host + " sulla porta " + port + " local port " + socket.getLocalPort());
			String userInput;
			System.out.print("Inserisci la matricola: ");
			while ((userInput = tastiera.nextLine()) != "") {
				sockOUT.println(userInput); // Invia al server
				System.out.println("Risposta dal server: " + sockIN.readLine()); // Riceve risposta
			}
		} catch (IOException e) {
			System.err.println("Errore nella comunicazione con il server: " + e.getMessage());
		}
	}
}