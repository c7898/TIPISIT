package it.salvemini;

import java.io.Serializable;
import java.util.ArrayList;

public class Studente implements Serializable {
	private String nome;
	private String cognome;
	private int matricola;
	private ArrayList<Float> voti;

	public Studente(String nome, String cognome, int matricola, ArrayList<Float> voti) {
		this.nome = nome;
		this.cognome = cognome;
		this.matricola = matricola;
		this.voti = voti;
	}

	public float Media() {
		float somma = 0;
		for (int i = 0; i < voti.size(); i++) {
			somma += voti.get(i);
		}
		float media = somma / voti.size();
		return media;
	}

	public String toString() {
		return "Matricola:" + matricola + " Nome:" + nome + " Cognome:" + cognome + " la media dei voti è: " + Media();
	}
}
