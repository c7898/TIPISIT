package nomecognome;


/**
 * Questa classe rappresenta un cognome e consente di fare controlli e conversioni
 */
public class Cognome extends Thread{
	String Cognome;
	Nome n;
	int var;
	
	/**
	 * Costruttore della classe
	 * @param Cognome stringa che rappresenta il nome testuale...
	 */
	public Cognome(String Cognome) {
		this.Cognome=Cognome;
		n=new Nome(Cognome);
	}
	
	public void run() {
		n.verifica(Cognome,3);
		if(n.var==1) {
			var=1;
		}

	}
}
