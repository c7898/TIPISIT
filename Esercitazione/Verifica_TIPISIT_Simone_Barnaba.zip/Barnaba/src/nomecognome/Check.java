package nomecognome;

import java.io.FileWriter;
import java.io.IOException;

public class Check {
	String Nome;
	String Cognome;
	Nome N;
	Cognome C;

	public Check(String Nome, String Cognome) {
		this.Nome = Nome;
		this.Cognome = Cognome;
		N = new Nome(Nome);
		C = new Cognome(Cognome);
	
	}

	public void check(FileWriter writer) throws InterruptedException, IOException {
	
		N.start();
		C.start();
		
		N.join();
		C.join();
		if (N.var == 0 && C.var == 0) {

			writer.write("Cognome: " + Cognome.toUpperCase() + " Nome: " + Nome.substring(0, 1).toUpperCase()
					+ Nome.substring(1).toLowerCase() + "\n");
			writer.flush();
			
		}
	}

}
