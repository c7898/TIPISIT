package nomecognome;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {

		try {
			File inputString = new File("strings.txt");
			Scanner input = new Scanner(inputString);
			FileWriter writer = new FileWriter("verifica.txt",true);
			String Nome;
			String Cognome;
			String line;
			System.out.println("Wait...");
			while (input.hasNextLine()) {

				line = input.nextLine();
				String[] mioarray = line.split("/");
				Nome = mioarray[1];
				Cognome = mioarray[0];
				Check gen = new Check(Nome, Cognome);
				gen.check(writer);
			}
			input.close();
			writer.close();
			System.out.println("Fine esequizione programma");
		} 
		catch(FileNotFoundException e) {
			System.out.println("Attenzione, non sto riuscendo a trovare il file...");
		}
		catch(IOException e) {
			System.out.println("Si è verificato un problema in lettura/scrittura del file");
		}
		catch(InterruptedException e) {
			System.out.println("Si è verificato un problema con i Thread");
		}		
		catch (Exception e) {
			System.out.println("Eccezione non prevista...");
			e.printStackTrace();
		}

	}

}
