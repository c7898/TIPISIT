package es10;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Scrittore {
	public Scrittore() {
		
	}
	
	public void FileWriter(Studente Studente) {
		try {
			FileOutputStream file = new FileOutputStream("Verifica.dat");
			try {
				ObjectOutputStream writer = new ObjectOutputStream(file);
				writer.writeObject(Studente);
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
