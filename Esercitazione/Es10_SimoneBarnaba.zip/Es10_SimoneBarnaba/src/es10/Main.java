package es10;

public class Main { 
	public static void main(String[] args) {
		Studente s = new Studente();
		s.Inserimento();
		Scrittore writer = new Scrittore();
		Lettore read= new Lettore();
		writer.FileWriter(s);
		read.fileReader();
	    
	}

}
