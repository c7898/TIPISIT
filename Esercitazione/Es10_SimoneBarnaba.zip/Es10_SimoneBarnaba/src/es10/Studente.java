package es10;

import java.io.NotSerializableException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@SuppressWarnings("serial")
public class Studente extends NotSerializableException {
	String nome;
	String cognome;
	float media;
	float somma;
	List <Float>voti;
	public List <Float> Inserimento() {
			try (Scanner tastiera = new Scanner(System.in)) {
				System.out.println("Inserisci il nome");
				nome=tastiera.nextLine();
				System.out.println("Inserisci il cognome");
				cognome= tastiera.nextLine();
				System.out.print("Quanti voti ha questo studente: ");
				String nvoti = tastiera.nextLine();
				float nvoto = Float.valueOf(nvoti);
				voti=  new ArrayList<Float>();
				float voto;
				for(int c=1; c<= nvoto; c++) {
					System.out.print(c+" Voto: ");
				    String votoletto = tastiera.nextLine();
				    voto = Float.valueOf(votoletto);
				    while (voto>10 || voto<2) {
				    	System.out.println("Non puoi inserire voti minore di 2 o maggiori di 10");
				    	System.out.println("Rienserire il voto "+c);
					    votoletto = tastiera.nextLine();
					    voto = Float.valueOf(votoletto);
				    }
				    somma= voto + somma;
				    voti.add(voto);
				}
				media= somma/voti.size();
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return voti;
	}
	
	public String toString() {
		return "Nome: "+nome + " Cognome: "+ cognome + " Media: "+ media;
	}

}
