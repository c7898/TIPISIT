package es10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


public class Lettore {
	
	Studente Studente;
	
	public Lettore() {
		
	}
	
	public void fileReader() {
		try {
			FileInputStream file = new FileInputStream("Verifica.dat");
			try {
				ObjectInputStream read = new ObjectInputStream(file);
				Studente s = (Studente)read.readObject();
				System.out.println("Ho letto la classe Studente \n"+s.toString());
				read.close();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
	}
	}	
	
}
