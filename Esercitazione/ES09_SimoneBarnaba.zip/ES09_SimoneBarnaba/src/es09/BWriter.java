package es09;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BWriter{
	private String stringa;
	public BWriter(String stringa){
		this.stringa=stringa;
	}
	
	public void Bscrittura(){
		long t1=System.currentTimeMillis();
		try(FileWriter file = new FileWriter("./BWriter.txt")){
			BufferedWriter writer = new BufferedWriter(file);
			for(int c=0;c<100000;c++) {
				writer.write(stringa+"\n");
			}
		}catch (IOException e) {
	        e.printStackTrace();
		}
		
		
	long t2=System.currentTimeMillis();
	System.out.println("Tempo classe BufferedWriter "+(t2-t1)+"s");
	}
}
