package es09;


public class Main {
	static String stringa;
	public static void main(String[] args) throws InterruptedException {
		stringa="stringa di test velocità";
		FWriter fw = new FWriter(stringa);
		BWriter bw = new BWriter(stringa);
		
		bw.Bscrittura();
		fw.Fscritura();

	}

	}

