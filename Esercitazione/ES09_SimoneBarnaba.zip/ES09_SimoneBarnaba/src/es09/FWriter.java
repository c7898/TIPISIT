package es09;

import java.io.FileWriter;
import java.io.IOException;

public class FWriter{
		private String stringa;
		public FWriter(String stringa){
			this.stringa=stringa;
		}
		
		public void Fscritura(){
			long t1=System.currentTimeMillis();
			try(FileWriter writer = new FileWriter("./FWriter.txt")){	
			for(int c=0;c<100000;c++) {
				writer.write(stringa+"\n");
			}
			}catch (IOException e) {
		        e.printStackTrace();
			}
		long t2=System.currentTimeMillis();
		System.out.println("Tempo classe FileWriter "+(t2-t1)+"ms");
		}
}