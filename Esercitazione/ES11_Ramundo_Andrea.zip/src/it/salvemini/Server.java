package it.salvemini;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) {
		int port = 1234; // Porta su cui il server ascolta
		try (ServerSocket serverSocket = new ServerSocket(port)) {
			System.out.println("Server in ascolto sulla porta " + port);
			while (true) {
// Accetta una connessione
				Socket clientSocket = serverSocket.accept();
				System.out.println("Connessione accettata da " + clientSocket.getInetAddress());
// Crea thread per gestire la connessione
				ClientHandler ch = new ClientHandler(clientSocket);

				ch.start();

			}
		} catch (IOException e) {
			System.err.println("Errore nel server: " + e.getMessage());
		}
	}
}

class ClientHandler extends Thread {
	private Socket clientSocket;

	public ClientHandler(Socket socket) {
		this.clientSocket = socket;
	}

	public void run() {
		try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
				PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
			
			String inputLine1= in.readLine();
			System.out.println("[" + clientSocket.getInetAddress() + "] Ricevuto1: " + inputLine1);
			int num1=Integer.parseInt(inputLine1);
			
			String inputLine2= in.readLine();
			System.out.println("[" + clientSocket.getInetAddress() + "] Ricevuto2: " + inputLine2);
			int num2=Integer.parseInt(inputLine2);
			
			int somma=num1+num2;
			
			out.println(somma);
		} catch (IOException e) {
			System.err.println("Errore nella comunicazione con il client " + clientSocket.getInetAddress() + ": "
					+ e.getMessage());
		} finally {
			System.out.println("Connessione chiusa da " + clientSocket.getInetAddress());
			try {
				clientSocket.close();
			} catch (IOException e) {
				System.err.println("Errore nella chiusura del socket client: " + e.getMessage());
			}
		}
	}
}