package it;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Thread_Writer extends Thread {
	private final Container resultContainer; // Contenitore da cui prendere i dati da scrivere

	public Thread_Writer(Container resultContainer) {
		this.resultContainer = resultContainer;
	}
	
	public void run() {
	    System.out.println("Writer: inizio...");
	    try (BufferedWriter writer = new BufferedWriter(new FileWriter("result.txt"))) {
	        while (true) {
	            String result = resultContainer.Get();
	            if (result == null) {
	                break;
	            }
	            System.out.println("Scrivo la stringa: " + result); // Messaggio di log
	            writer.write(result);
	            writer.newLine();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	    System.out.println("Writer: finito...");
	}
	}

