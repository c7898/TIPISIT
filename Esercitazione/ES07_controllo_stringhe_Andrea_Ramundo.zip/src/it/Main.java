package it;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
		try {
			File inputString = new File("strings.txt");
			Scanner input = new Scanner(inputString);
			Container container1 = new Container();
			Container resultContainer = new Container();

			// Avvio dei thread
			Thread_Reader reader = new Thread_Reader(container1, input);
			Thread_Cecker cecker = new Thread_Cecker(container1, resultContainer);
			Thread_Writer writer = new Thread_Writer(resultContainer);

			reader.start();
			cecker.start();
			writer.start();

			// Aspetta che i thread finiscano
			reader.join();
			container1.completato();
			cecker.join();
			resultContainer.completato();
			writer.join();

			input.close();
			
		} catch (FileNotFoundException e) {
			System.out.println("File non trovato: " + e.getMessage());
		} catch (InterruptedException e) {
			System.out.println("Errore nell'interruzione dei thread: " + e.getMessage());
		}
	}
}
