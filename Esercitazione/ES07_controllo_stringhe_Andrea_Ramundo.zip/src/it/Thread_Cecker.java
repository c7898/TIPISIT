package it;

public class Thread_Cecker extends Thread {
	private final Container c1;
	private final Container resultContainer;
	private int c;
	private int h;

	public Thread_Cecker(Container c1, Container resultContainer) {
		this.c1 = c1;
		this.resultContainer = resultContainer;
	}
	
	
	public void run() {
	    System.out.println("Cecker: inizio...");
	    while (true) {
	        String data = c1.Get(); // Prendi i dati dal container
	        if (data == null) {
	            break;
	        }
	        StringBuilder result = new StringBuilder();

			c = 0;
			h = 0;

			if (data == null || !data.contains("/")) {
				result.append("Errore: formato non valido. Deve contenere il carattere '/'");
			} else {
				int separatorIndex = data.indexOf('/');
				String str = data.substring(0, separatorIndex);
				result.append("Nome: ");
				result.append(Lenght(str));
				result.append(Carattere(str));

				if (c == 0) {
					result.append(str.substring(0, 1).toUpperCase()).append(str.substring(1).toLowerCase());
				} else {
					result.append("non corretto");
				}

				result.append(" Cognome: ");
				String str_cognome = data.substring(separatorIndex + 1);
				result.append(Cognome_Lenght(str_cognome));
				result.append(Cognome_Carattere(str_cognome));

				if (h == 0) {
					result.append(str_cognome.toUpperCase());
				} else {
					result.append("non corretto");
				}
			}

			resultContainer.Put(result.toString());
	    }
	    System.out.println("Cecker: fine...");
	}


	public String Lenght(String str) {
		if (str.length() <= 2) {
			c = 1;
			return "Deve contenere almeno 2 caratteri, ";
		}
		return "";
	}

	public String Carattere(String str) {
		for (int i = 0; i < str.length(); i++) {
			if (!Character.isLetter(str.charAt(i))) {
				c = 1;
				return "Ci sono caratteri speciali, ";
			}
		}
		return "";
	}

	public String Cognome_Carattere(String str) {
		for (int i = 0; i < str.length(); i++) {
			if (!Character.isLetter(str.charAt(i))) {
				h = 1;
				return "Ci sono caratteri speciali, ";
			}
		}
		return "";
	}

	public String Cognome_Lenght(String str) {
		if (str.length() <= 3) {
			h = 1;
			return "Deve contenere almeno 2 caratteri, ";
		}
		return "";
	}
}
