package it;

import java.util.Scanner;

public class Thread_Reader extends Thread {
	protected Container c;
	protected Scanner input;

	public Thread_Reader(Container c, Scanner input) {
		this.c = c;
		this.input = input;
	}

	public void run() {
		
		System.out.println("Reader: inizio...");

		while (input.hasNextLine()) {
			String line = input.nextLine();
			c.Put(line);
		}
		
		System.out.println("Reader: finito...");
	}
}
