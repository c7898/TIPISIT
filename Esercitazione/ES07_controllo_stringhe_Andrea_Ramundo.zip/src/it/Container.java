package it;

import java.util.Stack;

public class Container {
	private boolean completato = false; // Indica se il container ha finito le sue stringhe
	private int limite = 100; // Limite massimo di stringhe nel container
	private int contatore = 0; // Contatore per il numero di stringhe presenti
	Stack<String> dati = new Stack<String>();

	public synchronized void Put(String s) {
		while (contatore >= limite) {
			try {
				wait(); // Aspetta che il dato venga consumato o che ci sia spazio
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		dati.push(s);
		notifyAll(); // Notifica i thread in attesa
	}

	public synchronized String Get() {
		while (dati.isEmpty()) {
			if (completato) {
				return null;
			}
			try {
				wait(); // Aspetta che il dato venga prodotto
				System.out.println("Sto aspettando che il dato venga prodotto");
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
		contatore--;
		return dati.pop();
	}

	public synchronized void completato() {
		completato = true;
		notifyAll(); // Notifica i thread in attesa per far terminare eventuali attese
	}

	public synchronized boolean isCompletato() {
		return completato;
	}
}
