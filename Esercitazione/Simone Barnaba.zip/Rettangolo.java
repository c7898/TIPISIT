

public class Rettangolo extends Figura {

	protected float base;
	protected float altezza;
	
	public Rettangolo(float base, float altezza) {
		nomeFigura ="Rettangolo";
		this.base= base;
		this.altezza= altezza;
	}
	public float calcolaArea() {
		
		return base*altezza ;
	}

	@Override
	public float calcolaPerimetro() {
		return (base+altezza)*2;
	}

}
