

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		
		ArrayList<Figura> figure = new ArrayList<Figura>();
		
		figure.add(new Cerchio(5));
		figure.add(new Cerchio(6));
		figure.add(new Quadrato(5));
		figure.add(new Cerchio(7));
		figure.add(new Rettangolo(5,7));
		
		for (Figura f2 : figure) {
			f2.descrivi();
			
		}
	}

}
