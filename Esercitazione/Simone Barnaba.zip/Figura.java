

public abstract class Figura {
		
public String nomeFigura;
	
	public abstract float calcolaArea();
	
	public abstract float calcolaPerimetro();
	
	public void descrivi() {
		System.out.println("sono un " + nomeFigura + " la mia area è " + calcolaArea() + " perimetro " + calcolaPerimetro());
	}
 	
}
