

public class Cerchio extends Figura {

	protected float raggio;
	
	public Cerchio (float raggio) {
		nomeFigura = "Cerchio";
		this.raggio = raggio;
	}
	
	@Override
	public float calcolaArea() {
		
		return (float)(3.14*raggio*raggio);
	}

	@Override
	public float calcolaPerimetro() {
		
		return (float)(2*3.14*raggio);
	}

}
