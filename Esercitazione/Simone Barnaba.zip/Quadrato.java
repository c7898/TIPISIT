

public class Quadrato extends Figura {

	protected float lato;

	//TODO: inserire il costruttore

	public Quadrato(float lato) {
		nomeFigura ="Quadrato";
		this.lato = lato;
	}

	@Override
	public float calcolaArea() {
		
		return 0; //TODO: inserire il codice
	}

	@Override
	public float calcolaPerimetro() {
		return 0; //TODO: inserire il codice
	}

}
