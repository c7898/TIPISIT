package pass;

public class Numero extends Thread {
	public int i;
	String pass1;
	int c;
	public Numero(int i,String pass1) {
		this.i= i;
		this.pass1=pass1;
		
	}
	
	public void run() {
		for (int i = 0; i < pass1.length(); i++) {
	        if (Character.isDigit(pass1.charAt(i))) {
	        	
	        	c=1;
	        }else {
	        	c=0;
	        }
		}
		/*System.out.println("thread numero ha trovato c = " + c);*/
	}
}
