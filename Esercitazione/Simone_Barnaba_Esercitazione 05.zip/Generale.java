package pass;

public class Generale {
	char t;
	String pass1;
	Lettara l;
	Spazio s;
	Lunghezza l1;
	Numero n;

	public Generale(String pass1) {
		this.pass1 = pass1;
		l = new Lettara(pass1, t);
		s= new Spazio(pass1);
		l1= new Lunghezza(pass1);
		n=new Numero(t, pass1);
		l.start();
		l1.start();
		n.start();
		s.start();
	}

	public void check() throws InterruptedException {
		l.join();
		l1.join();
		n.join();
		s.join();
		
		if ((l.c==1) && (l.c==1)&&(l1.c==1) && (n.c==1)&&(s.c==1)) {
			System.out.println("La password rispette tutte le indicazioni richieste.");
		} else {
			System.out.println("La password NON rispette tutte le indicazioni richieste.");
		}
	}

}
