package pass;

public class Lettara extends Thread{
	public int c=1;
	String pass1;
	char start;
	public Lettara(String pass1,char start) {
		this.pass1=pass1;
		this.start=start;
		
	}
	
	
	public void run() {
		char carattere;
        for(int i=0;i<26;i++) {
        	carattere = (char) (start+i);
            if(pass1.indexOf(carattere)!=-1) {
                c=0;
            }
            }
        /*System.out.println("thread lettera ha trovato c = " + c);*/
	}

}

