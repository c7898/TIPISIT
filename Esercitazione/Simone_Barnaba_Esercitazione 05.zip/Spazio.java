package pass;

public class Spazio extends Thread{
	public int c;
	String pass1;
	public Spazio(String pass1) {
		this.pass1=pass1;
		
	}
	
	public void run() {
		if(pass1.indexOf(" ")==-1) {
			 c=1;
		 }else{
			 c=0;
		 }
		/*System.out.println("thread spazio ha trovato c = " + c);*/
	}

}
