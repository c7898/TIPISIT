package pass;

public class Lunghezza extends Thread{
	public int c;
	String pass1;
	public Lunghezza(String pass1) {
		this.pass1=pass1;
		
	}
	
	public void run() {
		if(pass1.length()<7) {
			c=0;
		 }else {
			 c=1;
		 }
		/*System.out.println("thread lunghezza ha trovato c = " + c);*/
	}

}
