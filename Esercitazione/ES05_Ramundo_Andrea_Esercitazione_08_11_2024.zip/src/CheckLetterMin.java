
public class CheckLetterMin extends Thread {
	private String pass;
	private int i;
	public CheckLetterMin(String pass) {
		this.pass=pass;
	}
	
public void run() {
		
		char current;
		boolean minuscola= false;
		for(int i=0;i<26;i++) {
			current = (char) ('a'+i);
			if(pass.indexOf(current)!=-1) {
				minuscola=true;
			}
			}
		if(minuscola==true) {
			System.out.println("✔ lettera minuscola");
			i=1;
		}
		else {
			System.out.println("X lettera minuscola");
		}
		
	}

	public int value() {
		return i;
	}

}
