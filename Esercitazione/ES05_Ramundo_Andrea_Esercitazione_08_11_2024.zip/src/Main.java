import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);
        System.out.print("Inserisci la password: ");
        String password = scanner.nextLine();
        
         CheckLenght  lunghezza=new CheckLenght(password);
		 CheckLetter maiuscola=new CheckLetter(password);
		 CheckLetterMin minuscola=new CheckLetterMin(password);
		 CheckSpace spazio=new CheckSpace(password);
		 CheckNumber numero=new CheckNumber(password);
		
		ArrayList<Thread> threads = new ArrayList<Thread>();
		
		threads.add(lunghezza);
		threads.add(maiuscola);
		threads.add(minuscola);
		threads.add(spazio);
		threads.add(numero);
		
		for(Thread check : threads) {
			check.start();
		}
		for(Thread check : threads) {
			try {
				check.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}	
		}
		
		if(lunghezza.value()==1 && maiuscola.value()==1 &&  minuscola.value()==1 && spazio.value()==1 && numero.value()==1) {
			System.out.println("La password ha tutti i requisiti minimi");
		}
		else {
			System.out.println("La password non rispetta tutti i requisiti minimi");
		}
		

		
        

		
		/*
		 * 
		 * 
		 * 		CheckLetter maiuscola=new CheckLetter("Password");
		
		threads.add(maiuscola);
		 * 
		 * 
		maiuscola.start();
		CheckLetterMin minuscola=new CheckLetterMin("Password");
		minuscola.start();
		CheckSpace spazio=new CheckSpace("Password");
		spazio.start();
		CheckNumber numero=new CheckNumber("Password");
		numero.start();
		
		
		*/
		
		
		
		
		
		
		/*
		JFrame frame=new JFrame("Password");
		JPanel panel=new JPanel(new GridLayout(2, 1));
		JButton button=new JButton("Verifica");
		JLabel label=new JLabel("Inserisci la tua password");
		JPasswordField passwordField = new JPasswordField(20);
		
		
		JTextArea Area = new JTextArea("Requisiti:\n"
                + "• Almeno 8 caratteri\n"
                + "• Almeno una lettera maiuscola\n"
                + "• Almeno una lettera minuscola\n"
                + "• Nessuno spazio\n"
                + "• Almeno un numero");
		

		
		frame.add(panel);
		frame.setSize(500, 300);
		frame.setVisible(true);
		panel.add(label);
		panel.add(Area);
		panel.add(passwordField);
		panel.add(button);
		
		
				
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				char[] password=passwordField.getPassword();
				String psw = new String(password);
				
		CheckLenght lunga=new CheckLenght(psw);
		lunga.start();
		CheckLetter maiuscola=new CheckLetter(psw);
		maiuscola.start();
		CheckLetterMin minuscola=new CheckLetterMin(psw);
		minuscola.start();
		CheckSpace spazio=new CheckSpace(psw);
		spazio.start();
		CheckNumber numero=new CheckNumber(psw);
		numero.start();
				
				
				
				
			
				pass.run();
			    StringBuilder message = new StringBuilder();
		        message.append(lunga.run()).append("\n");
		        message.append(maiuscola.run();).append("\n");
		        message.append(minuscola.run();).append("\n");
		        message.append(spazio.run();).append("\n");
		        message.append(numero.run();).append("\n");
		        
		        JOptionPane.showMessageDialog(null, message.toString(), "Verifica Password", JOptionPane.INFORMATION_MESSAGE);
		        
		        passwordField.setText("");
			}
			
			
		});
		*/
	}
}


