
public class CheckLenght extends Thread {
	
	private String pass;
	private int i;
	
	public CheckLenght(String pass) {
		this.pass=pass;
		
	}
	
	public void run() {
		
			if(pass.length()>=8) {
				System.out.println("✔ 8 caratteri");
				i=1;
			}
			else {
				System.out.println("X 8 caratteri");
			}
		
	}
	
	public int value() {
		return i;
	}
}
