
public class CheckNumber extends Thread {
	private String pass;
	private int i;

	public CheckNumber(String pass) {
		this.pass=pass;
	}
	
	public void run() {
		
		if(pass.matches(".*\\d.*")) {
			System.out.println("✔ numero");
			i=1;
		}
		else {
			System.out.println("X numero");
		}
		
	}
	
	public int value(){
		return i;
	}
}
