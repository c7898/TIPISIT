
public class CheckSpace extends Thread {
	private String pass;
	private int i;
	
	public CheckSpace(String pass) {
		this.pass=pass;
	}
	
	public void run() {
		if(pass.contains(" ")) {
			System.out.println("X Contiene lo spazio"); 
		}
		else {
			System.out.println("✔ Non contiene lo spazio");
			i=1;
		}
		
	}
	
	public int value() {
		return i;
	}
}
