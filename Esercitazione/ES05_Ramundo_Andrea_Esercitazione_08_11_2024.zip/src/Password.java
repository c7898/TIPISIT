public class password extends Thread {

	private String pass;
	private int i;

	public Password(String pass) {
		this.pass=pass;
	}

	
	public String CheckLength() {
		if(pass.length()>=8) {
			return "✔ 8 caratteri";
		}
		else {
			return "X 8 caratteri";
		}
	}
	
	public String CheckLetter() {
		
		char current;
		boolean maiuscola= false;
		for(int i=0;i<26;i++) {
			current = (char) ('A'+i);
			if(pass.indexOf(current)!=-1) {
				maiuscola=true;
			}
			}
		if(maiuscola==true) {
			return "✔ lettera maiuscola";
		}
		else {
			return "X lettera maiuscola";
		}
		
	}
	
	public String Checkletter() {
		
		char current;
		boolean minuscola= false;
		for(int i=0;i<26;i++) {
			current = (char) ('a'+i);
			if(pass.indexOf(current)!=-1) {
				minuscola=true;
			}
			}
		if(minuscola==true) {
			return "✔ lettera minuscola";
		}
		else {
			return "X lettera minuscola";
		}
		
	}
	
	public String CheckSpace() {
		if(pass.contains(" ")) {
			return "X Contiene lo spazio";
		}
		else {
			return "✔ Non contiene lo spazio";
		}
		
	}
	
	public String CheckNumber() {
		
		if(pass.matches(".*\\d.*")) {
			return "✔ numero";
		}
		else {
			return "X numero";
		}
		
	}
	
}
	

