package ping;

import java.io.IOException;
import java.net.InetAddress;
import java.util.EmptyStackException;

public class Checker extends Thread{
	Container C1;
	Container C2;
	
	public Checker(Container C1, Container C2) {
		this.C1=C1;
		this.C2=C2;
	}
	
	
	public synchronized void run() {
		String IP;
		String IP2;
		boolean lavoro= true;
		while(lavoro) {
			try {
				IP= C1.get();
				InetAddress address = InetAddress.getByName(IP);
				address.isReachable(1);
				if(address.isReachable(1) == true) {
					IP2= ("L'indirizzo "+ IP +" ha risposto \n");
				}else {
					IP2= ("L'indirizzo "+ IP +" non ha risposto \n");
				}
				C2.put(IP2);
			}catch (EmptyStackException e) {
				if(C1.isFinish()) {
					lavoro=false;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
	}
		C2.setFinish();

}
}
