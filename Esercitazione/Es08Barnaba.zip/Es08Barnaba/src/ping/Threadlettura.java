package ping;

import java.util.Scanner;


public class Threadlettura extends Thread{
	Scanner input;
	Container C1;
	public Threadlettura(Scanner input, Container C1) {
		this.input= input;
		this.C1= C1;
	}
	
	public synchronized void run() {
		String IP;
		while (input.hasNextLine()) {
			IP = input.nextLine();
			C1.put(IP);
		}
		C1.setFinish();
	}

}
