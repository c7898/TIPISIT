package ping;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try {
			File inputString = new File("IP.txt");
			Scanner input = new Scanner(inputString);
			Container C1 = new Container();
			Container C2 = new Container();
			Threadlettura threadlettura = new Threadlettura(input, C1);
			Threadscrittura threadscrittura = new Threadscrittura(C2);
			Checker Check = new Checker(C1, C2);
			System.out.println("Wait...");
			threadlettura.start();	
			Check.start();
			threadscrittura.start();
			threadlettura.join();
			Check.join();
			threadscrittura.join();
			input.close();
			System.out.println("Fine esequzione");
			
		} catch (FileNotFoundException e) {
			System.out.println("Attenzione, non sto riuscendo a trovare il file...");
			e.printStackTrace();
		}
		catch (Exception e) {
			System.out.println("Eccezione non prevista...");
			e.printStackTrace();
		}

	}

}
