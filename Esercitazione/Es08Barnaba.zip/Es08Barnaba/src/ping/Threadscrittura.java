package ping;

import java.io.FileWriter;
import java.io.IOException;
import java.util.EmptyStackException;

public class Threadscrittura extends Thread {
	Container C2;
	public Threadscrittura(Container C2) {
		this.C2=C2;
	}
	
	public void run() {
		FileWriter writer = null;
		try {
			writer = new FileWriter("verifica.txt");
		} catch (Exception e) {
			// TODO: handle exception
		}
		boolean lavoro=true;
		String IP;
		while(lavoro) {
			
			try {
					IP= C2.get();
	            	writer.write(IP);

			} catch (EmptyStackException e) {
				if(C2.isFinish()) {
					lavoro=false;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	}
}
		try {
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
