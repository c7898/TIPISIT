package ping;

import java.util.Stack;

public class Container {
	
	private final Stack<String> dati;
	private boolean finish = false;

	public Container() {
		dati = new Stack<String>();

	}

	public synchronized boolean isFinish() {
		return finish;
	}

	public synchronized void setFinish() {
		finish = true;
		notifyAll();
	}

	public synchronized void put(String s) {

		dati.push(s);
		notifyAll();

	}

	public synchronized String get() {
		return dati.pop();
	}

}
